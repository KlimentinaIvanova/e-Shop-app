
 const Home=()=>{
    return(
        <section className="banner_main">
        
         
            <div className="col-md-5">
            </div>
            <div className="col-md-7 padding_right1">
            </div>
      </section>
    )
}
export default Home